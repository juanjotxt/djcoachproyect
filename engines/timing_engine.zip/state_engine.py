"""
state_engine.py v3

DJCoach Pro - Real-time DJ State Model

Convierte eventos en estado operativo del DJ.
"""
from models.deck_state import DeckState

class DJStateEngine:

    def __init__(self):

         # ----------------------------------
         # DECKS
         # ----------------------------------

         self.deck_a = DeckState(deck="A")
         self.deck_b = DeckState(deck="B")

        # -----------------------------
        # CROSSFADE / MIX
        # -----------------------------

        self.crossfader = 0.5  # 0 = A, 1 = B
        self.mix_state = "IDLE"  # IDLE / A_ONLY / B_ONLY / TRANSITION

        # -----------------------------
        # ACTIVITY TRACKING
        # -----------------------------

        self.last_event = None
        self.current_activity = None

    def get_deck(self, deck_id: str) -> DeckState:
        """

        Devuelve el objeto DeckState correspondiente
        al deck solicitado.
        """

        if deck_id == "A":
            return self.deck_a

        elif deck_id == "B":
            return self.deck_b

        raise ValueError(f"Deck desconocido: {deck_id}")

    # -------------------------------------------------

    def process(self, event):

        if event is None:
            return

        etype = event.get("type")
        value = event.get("value")

        self.last_event = event

        # -------------------------------------------------
        # PITCH (Deck control)
        # -------------------------------------------------

        if etype == "PITCH":

            self.deck_a["pitch"] = value
            self.deck_a["last_action"] = "PITCH_CHANGE"

            self.current_activity = "ADJUSTING_TEMPO"

        # -------------------------------------------------
        # CROSSFADER
        # -------------------------------------------------

        elif etype == "CROSSFADER":

            self.crossfader = value

            if value < 0.4:
                self.mix_state = "A_ONLY"
            elif value > 0.6:
                self.mix_state = "B_ONLY"
            else:
                self.mix_state = "TRANSITION"

            self.current_activity = "MIXING"

        # -------------------------------------------------
        # NOTE ON (PLAY / CUE simplificado)
        # -------------------------------------------------

        elif etype.startswith("NOTE_"):

            note_id = etype.split("_")[1]

            self.current_activity = f"TRIGGER_NOTE_{note_id}"

        # -------------------------------------------------
        # JOG / SCRATCH
        # -------------------------------------------------

        elif etype == "JOG_SCRATCH":

            self.current_activity = "SCRATCHING"

        elif etype == "JOG_BEND":

            self.current_activity = "BENDING"

        # -------------------------------------------------

        self.deck_a["last_event"] = event

    # -------------------------------------------------

    def get_state(self):

        return {
            "deck_a": self.deck_a,
            "deck_b": self.deck_b,
            "crossfader": self.crossfader,
            "mix_state": self.mix_state,
            "current_activity": self.current_activity
        }

    # -------------------------------------------------

    def reset(self):

        self.__init__() 