"""
DJCoach PRO
event_engine.py v2.1
"""

from copy import deepcopy

from models.dj_event import DJEvent
from models.event_types import EventType


class DJEventEngine:

    def __init__(self):
        self.previous_state = None
        self.event_counter = 0

    def _new_event(self, **kwargs):
        self.event_counter += 1
        return DJEvent(
            event_id=self.event_counter,
            source="STATE_ENGINE",
            **kwargs
        )

    def reset(self):
        self.previous_state = None
        self.event_counter = 0

    def process(self, state):

        events = []

        if self.previous_state is None:
            self.previous_state = deepcopy(state)
            return events

        prev = self.previous_state
        curr = state

        # -------------------------
        # TRACK A START
        # -------------------------
        if not prev["deck_a"]["playing"] and curr["deck_a"]["playing"]:
            events.append(self._new_event(
                event_type=EventType.TRACK_STARTED,
                deck="A",
                from_state=prev["mix_state"],
                to_state=curr["mix_state"],
                severity="INFO"
            ))

        # TRACK A STOP
        if prev["deck_a"]["playing"] and not curr["deck_a"]["playing"]:
            events.append(self._new_event(
                event_type=EventType.TRACK_STOPPED,
                deck="A",
                from_state=prev["mix_state"],
                to_state=curr["mix_state"],
                severity="INFO"
            ))

        # -------------------------
        # TRACK B START
        # -------------------------
        if not prev["deck_b"]["playing"] and curr["deck_b"]["playing"]:
            events.append(self._new_event(
                event_type=EventType.TRACK_STARTED,
                deck="B",
                from_state=prev["mix_state"],
                to_state=curr["mix_state"],
                severity="INFO"
            ))

        # TRACK B STOP
        if prev["deck_b"]["playing"] and not curr["deck_b"]["playing"]:
            events.append(self._new_event(
                event_type=EventType.TRACK_STOPPED,
                deck="B",
                from_state=prev["mix_state"],
                to_state=curr["mix_state"],
                severity="INFO"
            ))

        # -------------------------
        # MIX STATE CHANGE
        # -------------------------
        if prev["mix_state"] != curr["mix_state"]:
            events.append(self._new_event(
                event_type=EventType.MIX_STATE_CHANGED,
                from_state=prev["mix_state"],
                to_state=curr["mix_state"],
                severity="INFO"
            ))

        # -------------------------
        # TRANSITION START
        # -------------------------
        if prev["mix_state"] != "TRANSITION" and curr["mix_state"] == "TRANSITION":
            events.append(self._new_event(
                event_type=EventType.TRANSITION_STARTED,
                from_state=prev["mix_state"],
                to_state=curr["mix_state"],
                severity="CRITICAL"
            ))

        # -------------------------
        # TRANSITION END
        # -------------------------
        if prev["mix_state"] == "TRANSITION" and curr["mix_state"] != "TRANSITION":
            events.append(self._new_event(
                event_type=EventType.TRANSITION_FINISHED,
                from_state=prev["mix_state"],
                to_state=curr["mix_state"],
                severity="CRITICAL"
            ))

        # -------------------------
        # SESSION IDLE
        # -------------------------
        if curr["mix_state"] == "IDLE" and prev["mix_state"] != "IDLE":
            events.append(self._new_event(
                event_type=EventType.SESSION_IDLE,
                from_state=prev["mix_state"],
                to_state="IDLE",
                severity="WARNING"
            ))

        self.previous_state = deepcopy(curr)

        return events